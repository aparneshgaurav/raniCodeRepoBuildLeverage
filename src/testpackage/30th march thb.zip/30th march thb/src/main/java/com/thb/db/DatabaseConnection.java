package com.thb.db;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;

public class DatabaseConnection {

        public static Connection getConnection() {

                System.out.println("-------- h2 JDBC Connection Testing ------");

                try {

                        Class.forName("com.mysql.jdbc.Driver");

                } catch (ClassNotFoundException e) {

                        System.out.println("Where is your nysql JDBC Driver?");
                        e.printStackTrace();

                }

                System.out.println("mysql JDBC Driver Registered!");

                Connection connection = null;

                try {

                        connection = DriverManager.getConnection(
                                        "jdbc:mysql://thoughtsbookdb.chlgvjamyt8h.us-west-2.rds.amazonaws.com:3306/thoughtsbookdb", "aparnesh",
                                        "aparnesh");

                } catch (SQLException e) {

                        System.out.println("Connection Failed! Check output console");
                        e.printStackTrace();

                }

                if (connection != null) {
                        System.out.println("You made it, take control your database now!");
                } else {
                        System.out.println("Failed to make connection!");
                }
                return connection;
        }
        
        public static void main(String[] args){
                System.out.println( "hello");
                getConnection();
        }

}
package com.thb.webservice.rest.client;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.thb.db.DatabaseConnection;

public class DBTest {
 public static void main(String[] args) throws SQLException{
	 
		 Boolean bool = false;
			Connection connection = DatabaseConnection.getConnection();
			try{
				System.out.println(connection);
				
			}
			finally{
				connection.close();
			}
	 
	 }
}

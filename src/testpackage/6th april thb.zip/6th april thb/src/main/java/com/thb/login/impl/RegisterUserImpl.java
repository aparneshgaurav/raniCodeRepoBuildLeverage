package com.thb.login.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.thb.db.DatabaseConnection;
import com.thb.login.RegisterUser;

public class RegisterUserImpl implements RegisterUser {

        public Boolean register(String username, String password, String sex , String urlData) throws SQLException {
                Boolean bool = false;
                Connection connection = DatabaseConnection.getConnection();
                try{
                        System.out.println(connection);
                        String sql = "insert into thoughtsbookdb.login values( ? , ? , ? , ? ) ";
                        PreparedStatement preparedStatement = connection.prepareStatement(sql);        
                        preparedStatement.setString(1,username);
                        preparedStatement.setString(2,password);
                        preparedStatement.setString(3,sex);
                        preparedStatement.setString(4, urlData);
                        bool = preparedStatement.execute();
                        
                }
                catch(SQLException e){
                        e.printStackTrace();
                }
                finally{
                        connection.close();
                }
                return bool ; 
        }
        
        public String getCategoryListForUser(String userName ) throws SQLException{
            String categoryList = "";
                   Connection connection = DatabaseConnection.getConnection();
                   try{
                           System.out.println(connection);
                           String sql = "select category  from thoughtsbookdb.userNameCategoryBookIdBookName  where username = ? ";
                           PreparedStatement preparedStatement = connection.prepareStatement(sql);        
                           preparedStatement.setString(1,userName);
                           ResultSet res = preparedStatement.executeQuery();
                           while(res.next()){
                                   categoryList = categoryList +","+ res.getString(1);
                           }
                   }
                   catch(SQLException e){
                           e.printStackTrace();
                   }
                   finally{
                           connection.close();
                   }
                   return categoryList ;
    }

        public void saveCategoryForUserName(String userName, String category) throws SQLException {
                // TODO Auto-generated method stub
                
                Boolean bool = false;
                Connection connection = DatabaseConnection.getConnection();
                try{
                        System.out.println(connection);
                        String sql = "insert into thoughtsbookdb.userNameCategoryBookIdBookName values( ? , ? , ? , ?) ";
                        PreparedStatement preparedStatement = connection.prepareStatement(sql);        
                        preparedStatement.setString(1,userName);
                        preparedStatement.setString(2,category);
                        preparedStatement.setString(3, "" );
                        preparedStatement.setString(4, "");
                        bool = preparedStatement.execute();
                }
                catch(SQLException e){
                        e.printStackTrace();
                }
                finally{
                        connection.close();
                }
                
        }

        public void saveBookDetails(String username, String category, String bookName, String pageNumber,
                        String pageContent) throws SQLException {
                // TODO Auto-generated method stub
                Boolean bool = false;
                Connection connection = DatabaseConnection.getConnection();
                try{
                        // first of all , check whether the book already exists , if so update the details of
                        // page content and topic in the same book
                        /*String sqlToFetchBookList = "select bookname from bookdetails";
                        PreparedStatement preparedStatementForBookList = connection.prepareStatement(sqlToFetchBookList);
                        ResultSet resutlSet = preparedStatementForBookList.executeQuery();
                        String bookList = "";
                        while(resutlSet.next()){
                                bookList  = bookList + "," + resutlSet.getString(1);
                        }
                        if(bookList.contains(bookName)){
                                System.out.println("this is the updation case");
                                String sqlForUpdation = " update bookdetails set pagecontent = ? , topicnumberandname = ?  where bookname= ?  and username= ?  and category = ?  ";
                                PreparedStatement preparedStatementForUpdation = connection.prepareStatement(sqlForUpdation);
                                preparedStatementForUpdation.setString(1, pageContent);
                                preparedStatementForUpdation.setString(2, pageNumber);
                                preparedStatementForUpdation.setString(3, bookName);
                                preparedStatementForUpdation.setString(4, username);
                                preparedStatementForUpdation.setString(5, category);
                                Boolean boolForUpdation = preparedStatementForUpdation.execute();
                        }*/
                        
                        // insert new book details 
                        
                        // parsing to get the topic number from the page number
                        String[] strArrayOfTopicNumberAndTopicContent = pageNumber.split(":");
                        String topicNumber = strArrayOfTopicNumberAndTopicContent[0];
                        String bookId = bookName+":"+topicNumber;
                        
                        /**
                         *
                         * If you find bookId repeated on similar concept of above commented code , in that case just update the 
                         * page content . 
                         */
                        
                        String sqlToFetchBookIdList = "select bookId from thoughtsbookdb.bookDetails";
                        PreparedStatement preparedStatementForBookIdList = connection.prepareStatement(sqlToFetchBookIdList);
                        ResultSet resutlSet = preparedStatementForBookIdList.executeQuery();
                        String bookIdList = "";
                        while(resutlSet.next()){
                                bookIdList  = bookIdList + "," + resutlSet.getString(1);
                        }
                        
                        if(bookIdList.contains(bookId)){
                                System.out.println("this is the updation case");
                                String sqlForUpdation = "update thoughtsbookdb.bookDetails set pagecontent = ? , topicnumberandname = ?  where bookId= ?  and username= ?  and category = ?  ";
                                PreparedStatement preparedStatementForUpdation = connection.prepareStatement(sqlForUpdation);
                                preparedStatementForUpdation.setString(1, pageContent);
                                preparedStatementForUpdation.setString(2, pageNumber);
                                preparedStatementForUpdation.setString(3, bookId);
                                preparedStatementForUpdation.setString(4, username);
                                preparedStatementForUpdation.setString(5, category);
                                Boolean boolForUpdation = preparedStatementForUpdation.execute();
                        }
                        
                        
                        /**
                         * Write code for book id having book name appended with topic number ( after parsing first element of 
                         * page number ) . Insert book detail in bookId . 
                         */
                        
                        else{
                        System.out.println(connection);
                        System.out.println("this is the new book details insertion case ");
                        String sql = "insert into thoughtsbookdb.bookDetails values ( ? , ? , ? , ? , ? , ?) ";
                        PreparedStatement preparedStatement = connection.prepareStatement(sql);        
                        preparedStatement.setString(1,bookId);
                        preparedStatement.setString(2,bookName);
                        preparedStatement.setString(3, pageContent);
                        preparedStatement.setString(4, username);
                        preparedStatement.setString(5, category);
                        preparedStatement.setString(6, pageNumber);
                        System.out.println("Saving of the book details is done");
                        bool = preparedStatement.execute();
                        }
                        
                }
                catch(SQLException e){
                        e.printStackTrace();
                }
                finally{
                        connection.close();
                }
        }

}
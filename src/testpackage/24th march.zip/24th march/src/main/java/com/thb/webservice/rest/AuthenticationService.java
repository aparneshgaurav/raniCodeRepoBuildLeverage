package com.thb.webservice.rest;

import java.io.UnsupportedEncodingException;
import java.sql.SQLException;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.thb.login.Authenticate;
import com.thb.model.RegisterBean;

@Component
@Path("/login")
public class AuthenticationService {
        @Autowired
        Authenticate  authenticate;
        RegisterBean registerBean;
        
        
        
        @GET
        @Path("{credentials}")
        public Response savePayment(@PathParam("credentials") String credentials) throws SQLException,UnsupportedEncodingException {
        		String[] parsedLoginData = credentials.split(":");
        		String username = parsedLoginData[0];
        		String password = parsedLoginData[1];
                Boolean bool = false;
                String result = "unauthenticated";
                try {
                        System.out.println(username);
                        System.out.println("encoded password is : "+password);
                        
                        byte[] valueDecoded= Base64.decodeBase64( password.getBytes("UTF-8") );
                        String passwordDecoded = new String(valueDecoded);
//                        System.out.println("Decoded value is " + new String(valueDecoded));
                        
                        
                        
                       /* byte[] bytes = password.getBytes("UTF-8");
                        String passwordDecoded = Base64.getEncoder().encodeToString(bytes);*/
                        System.out.println("decoded password is : "+passwordDecoded);
                        
                        
                        bool = authenticate.authenticateLoginData(username,passwordDecoded);
                } catch (UnsupportedEncodingException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                }
                if(bool){
                        result = "authenticated";
                }
                else {
                        result = "unauthenticated";
                }
                System.out.println(" authentication result is :"+result+":");
                return Response.status(200).entity(result).build();
        } // end of method login authentication
        
        
        
        @GET
        @Path("getUserData/{username}")
        public Response getUserData(@PathParam("username") String username) {
                String result = "unauthenticated";
                try {
                        System.out.println(username);
                         registerBean = authenticate.getUserData(username);
                } catch (Exception e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                }
                if(registerBean==null){
                        result = "Sorry , some issues in retrieving the user data !";
                }
                else {
                        result = registerBean.getUrlData();
                }
//                System.out.println("result is "+result);
                return Response.status(200).entity(result).build();
        } // end of method login authentication
        
        
        @GET
        @Path("getBookListForUserAndCategory/{username}/{category}")
        public Response getBookListForUserAndCategory(@PathParam("username") String username , @PathParam("category") String category) {
                String result = "";
                try {
                        result = authenticate.getBookList(username,category);
                } catch (SQLException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                }
                return Response.status(200).entity(result).build();
        } // end of method login authentication
        
        @GET
        @Path("getBookDetails/{username}/{category}/{bookName}")
        public Response getBookDetailsForUserCategoryAndBookName(@PathParam("username") String username , @PathParam("category") String category , @PathParam("bookName") String bookName) {
                String result = "";
                System.out.println("entered the method for getBookDetails . ");
                try {
                        result = authenticate.getBookDetailsForUserCategoryAndBookName(username,category,bookName);
                } catch (SQLException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                }
                return Response.status(200).entity(result).build();
        } // end of method login authentication
        
        @GET
        @Path("getBookDetailsByBookId/{username}/{category}/{bookId}")
        public Response getBookDetailsForUserCategoryAndBookId(@PathParam("username") String username , @PathParam("category") String category , @PathParam("bookId") String bookId) {
                String result = "";
                System.out.println("entered the method for getBookDetails . ");
                try {
                        result = authenticate.getBookDetailsForUserCategoryAndBookId(username,category,bookId);
                } catch (SQLException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                }
                return Response.status(200).entity(result).build();
        } // end of method login authentication
        
        @GET
        @Path("getCategoriesListForUser/{username}")
        public Response getCategoriesListForUser(@PathParam("username") String username ) {
                String result = "";
                try {
                        result = authenticate.getCategoryListForUser(username);
                } catch (SQLException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                }
                return Response.status(200).entity(result).build();
        } // end of method login authentication
        
}

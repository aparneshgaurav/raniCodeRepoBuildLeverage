package org.sparkexample;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;





import org.apache.spark.sql.types.StructType;

import java.io.IOException;
// $example on$
import java.io.Serializable;

import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.ml.Pipeline;
import org.apache.spark.ml.PipelineModel;
import org.apache.spark.ml.PipelineStage;
import org.apache.spark.ml.evaluation.RegressionEvaluator;
import org.apache.spark.ml.param.ParamMap;
import org.apache.spark.ml.recommendation.ALS;
import org.apache.spark.ml.recommendation.ALSModel;
// $example off$ ../bin/spark-submit --class org.sparkexample.JavaALSExample --master local[2] ../../test-0.0.1-SNAPSHOT.jar

public class JavaALSExample {

  // $example on$
  public static class Rating implements Serializable {
    private int userId;
    private int movieId;
    private float rating;
    private long timestamp;

    public Rating() {}

    public Rating(int userId, int movieId, float rating, long timestamp) {
      this.userId = userId;
      this.movieId = movieId;
      this.rating = rating;
      this.timestamp = timestamp;
    }

    public int getUserId() {
      return userId;
    }

    public int getMovieId() {
      return movieId;
    }

    public float getRating() {
      return rating;
    }

    public long getTimestamp() {
      return timestamp;
    }

    public static Rating parseRating(String str) {
      String[] fields = str.split(",");
      if (fields.length != 4) {
        throw new IllegalArgumentException("Each line must contain 4 fields");
      }
      int userId = Integer.parseInt(fields[0]);
      int movieId = Integer.parseInt(fields[1]);
      float rating = Float.parseFloat(fields[2]);
      long timestamp = Long.parseLong(fields[3]);
      return new Rating(userId, movieId, rating, timestamp);
    }
  }
  // $example off$

  public static void main(String[] args) throws IOException {
    SparkSession spark = SparkSession
      .builder()
      .appName("JavaALSExample")
      .getOrCreate();

    // $example on$
    JavaRDD<Rating> ratingsRDD = spark
      .read().textFile("/home/cloudera/dev/ml-latest-small/ratings1.csv").javaRDD()
      .map(new Function<String, Rating>() {
    	    public Rating call(String str) {
    	        return Rating.parseRating(str);
    	      }
    	    });
    Dataset<Row> ratings = spark.createDataFrame(ratingsRDD, Rating.class);
    Dataset<Row>[] splits = ratings.randomSplit(new double[]{0.8, 0.2});
    Dataset<Row> training = splits[0];
    Dataset<Row> test = splits[1];

    // Build the recommendation model using ALS on the training data
    ALS als = new ALS()
      .setMaxIter(5)
      .setRegParam(0.01)
      .setUserCol("userId")
      .setItemCol("movieId")
      .setRatingCol("rating");
    
    Pipeline pipeLine = new Pipeline().setStages(new PipelineStage[]{als});
//    Pipeline pipeLine = new pipeli
    
    
//    ALSModel model = als.fit(training);
    PipelineModel pipelineModel = pipeLine.fit(training);
    
    
//    PipelineModel ppModel = als.fit(training);
//    model.
    pipelineModel.save("/home/cloudera/dev/jars/als.ser");

    // Evaluate the model by computing the RMSE on the test data
    // Note we set cold start strategy to 'drop' to ensure we don't get NaN evaluation metrics
//    model.setColdStartStrategy("drop");
    Dataset<Row> predictions = pipelineModel.transform(test).na().drop();
    
//    predictions.
    
    System.out.println("######################"+predictions.count());
    System.out.println("json : "+predictions.toJSON().toString());
    
    for (Row row : predictions.select("userId", "movieId", "rating").collectAsList()) {
    		System.out.println("hello");
    	  System.out.println("(" + row.get(0) + ", " + row.get(1) + ") --> prediction=" + row.get(2));
    	}

    RegressionEvaluator evaluator = new RegressionEvaluator()
      .setMetricName("rmse")
      .setLabelCol("rating")
      .setPredictionCol("prediction");
    Double rmse = evaluator.evaluate(predictions);
    System.out.println("Root-mean-square error = " + rmse);
  
    // $example off$
    spark.stop();
  }  
  
}

/*
 * [cloudera@quickstart bin]$ pwd
/home/cloudera/dev/jars/spark-2.1.0-bin-hadoop2.7/bin
[cloudera@quickstart bin]$ spark-submit --version
Welcome to
      ____              __
     / __/__  ___ _____/ /__
    _\ \/ _ \/ _ `/ __/  '_/
   /___/ .__/\_,_/_/ /_/\_\   version 1.3.0
      /_/
                        
Type --help for more information.
[cloudera@quickstart bin]$ 

 */


/*
 [cloudera@quickstart ml-latest-small]$ cat ratings1.csv 
668,608,5.0,993613478
668,720,3.0,993613415
668,1089,3.0,993613415
668,1213,5.0,993613359
668,1221,5.0,993613196
668,1233,4.0,993613415
668,1358,4.0,993613415
668,1490,1.0,993613196
668,2324,5.0,993613359
668,2501,3.0,993613415
668,2908,5.0,993613415
668,2997,5.0,993613478
668,3000,3.0,993613196
668,3039,3.0,993613196
668,3213,3.0,993613359
668,4012,3.0,993613196
668,6425,1.0,993613478
669,223,4.0,1015829358
669,260,5.0,1015829081
669,381,3.0,1015829160
669,480,3.0,1015829160
669,785,4.0,1015829525
669,913,5.0,1015829525
669,968,4.0,1015829545
669,1135,3.0,1015829160
669,1210,3.0,1015829115
669,1304,5.0,1015829081
669,1513,3.0,1015829690
669,1953,4.0,1015829081
669,2174,3.0,1015829081
669,2395,4.0,1015829738
669,2396,4.0,1015829738
669,2599,4.0,1015829431
669,2683,4.0,1015829288
669,2688,3.0,1015829462
669,2702,3.0,1015829766
669,2706,4.0,1015829288
669,2713,2.0,1015829525
669,2719,2.0,1015829462
669,2722,2.0,1015829081
669,2772,3.0,1015829395
669,2840,4.0,1015829738
669,2881,3.0,1015829395
669,2959,5.0,1015829431
669,2976,4.0,1015829358
669,3016,3.0,1015829395
669,3174,3.0,1015829525
669,3219,3.0,1015829662
669,3326,2.0,1015829081
669,3453,2.0,1015829462
669,3752,4.0,1015829525
669,3826,2.0,1015829486
669,3863,3.0,1015829358
669,4015,2.0,1015829115
670,1,4.0,938782344
670,25,5.0,938782344
670,32,3.0,938782145
670,34,4.0,938782193
670,36,4.0,938782050
670,47,5.0,938782050
670,50,5.0,938781934
670,110,3.0,938782093
670,150,3.0,938782006
670,318,5.0,938781934
670,457,4.0,938782414
670,527,5.0,938782006
670,590,1.0,938782094
670,593,5.0,938782234
670,608,5.0,938782093
670,1183,5.0,938782193
670,1245,1.0,938782281
670,1584,4.0,938782344
670,1617,2.0,938781934
670,1704,4.0,938781934
670,1923,2.0,938782414
670,2269,3.0,938782344
670,2291,4.0,938782145
670,2571,4.0,938782234
670,2628,4.0,938782234
670,2683,5.0,938782281
670,2723,2.0,940944033
670,2759,5.0,940943832
670,2770,4.0,938781328
670,2858,3.0,940943832
670,2912,5.0,940943887
671,1,5.0,1064891129
671,36,4.0,1065149314
671,50,4.5,1064890944
671,230,4.0,1064890230
671,260,5.0,1064891246
671,296,4.0,1064890424
671,318,5.0,1064890397
671,356,5.0,1063503911
671,357,3.0,1063503998
671,432,2.5,1063503739
671,457,4.0,1065149159
671,529,4.0,1064891534
671,551,5.0,1063503908
671,588,4.0,1065149478
671,589,5.0,1064891610
671,590,4.0,1065149296
671,608,4.0,1064890575
671,745,4.0,1065149085
671,919,4.0,1065149458
671,1035,5.0,1065149492
671,1036,3.5,1064891601
671,1080,4.0,1063500827
671,1090,4.0,1064891507
671,1136,5.0,1064891032
671,1148,5.0,1064891021
671,1196,5.0,1064890635
671,1197,3.5,1064891576
671,1198,5.0,1064891024
671,1206,3.0,1063500775
671,1220,4.0,1065149467
671,1223,3.0,1064891236
671,1225,4.0,1065149143
671,1240,4.0,1064891597
671,1247,4.0,1063500804
671,1259,4.0,1064890570
671,1265,4.0,1063503895
671,1266,4.0,1065149270
671,1291,4.0,1064891140
671,1387,4.0,1064891659
671,1610,4.0,1064891635
671,1641,4.0,1063503954
671,1673,3.5,1063500961
671,1676,3.0,1065108970
671,1704,4.0,1064890702
671,1923,4.0,1063502756
671,2011,3.5,1063500873
671,2028,4.0,1064891584
671,2064,4.0,1063502750
671,2194,3.5,1064891593
671,2291,5.0,1063500850
671,2324,4.0,1063500858
671,2355,4.0,1063500762
671,2359,4.0,1063503933
671,2396,4.0,1063503920
671,2401,4.0,1065149286
671,2502,3.5,1063503856
671,2571,4.5,1064891076
671,2683,4.0,1063500751
671,2762,4.0,1064891036
671,2795,3.5,1063503695
671,2797,4.0,1063500821
671,2804,5.0,1064890525
671,2858,4.0,1063503841
671,2918,4.0,1065149106
671,2959,4.0,1064890427
671,2997,4.5,1063503848
671,3052,1.0,1063503966
671,3060,4.0,1063503947
671,3114,5.0,1064891089
671,3147,4.0,1064891516
671,3160,3.0,1063503682
671,3253,3.0,1063503940
671,3271,4.0,1070940360
671,3386,4.0,1074784735
671,3421,4.0,1063502737
671,3481,2.0,1064245565
671,3671,3.0,1065149267
671,3751,4.0,1065111939
671,3897,2.0,1063503718
671,3996,3.5,1064245511
671,4011,4.0,1064245574
671,4019,3.5,1065111959
671,4022,3.5,1063500953
671,4027,4.0,1063500993
671,4033,4.0,1065111954
671,4034,4.5,1064245493
671,4306,5.0,1064245548
671,4308,3.5,1065111985
671,4880,4.0,1065111973
671,4886,5.0,1064245488
671,4896,5.0,1065111996
671,4963,4.5,1065111855
671,4973,4.5,1064245471
671,4993,5.0,1064245483
671,4995,4.0,1064891537
671,5010,2.0,1066793004
671,5218,2.0,1065111990
671,5299,3.0,1065112004
671,5349,4.0,1065111863
671,5377,4.0,1064245557
671,5445,4.5,1064891627
671,5464,3.0,1064891549
671,5669,4.0,1063502711
671,5816,4.0,1065111963
671,5902,3.5,1064245507
671,5952,5.0,1063502716
671,5989,4.0,1064890625
671,5991,4.5,1064245387
671,5995,4.0,1066793014
671,6212,2.5,1065149436
671,6268,2.5,1065579370
671,6269,4.0,1065149201
671,6365,4.0,1070940363
671,6385,2.5,1070979663
671,6565,3.5,1074784724

 */

/*
 [cloudera@quickstart bin]$ cat output2.txt 
json : [value: string]
hello
(671, 2396) --> prediction=4.0
hello
(670, 1) --> prediction=4.0
hello
(671, 590) --> prediction=4.0
hello
(670, 318) --> prediction=5.0
hello
(669, 2959) --> prediction=5.0
hello
(670, 50) --> prediction=5.0
hello
(671, 1923) --> prediction=4.0
hello
(671, 2291) --> prediction=5.0
hello
(670, 457) --> prediction=4.0
hello
(668, 608) --> prediction=5.0
hello
(671, 260) --> prediction=5.0
Root-mean-square error = 4.733601770366344

 */


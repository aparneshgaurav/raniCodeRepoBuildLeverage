package com.thb.login.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Store;

import com.thb.db.DatabaseConnection;
import com.thb.login.RegisterUser;

public class RegisterUserImpl implements RegisterUser {

        public Boolean register(String username, String password, String emailId , String urlData) throws SQLException {
                Boolean bool = false;
                Connection connection = DatabaseConnection.getConnection();
                try{
                        System.out.println(connection);
                        String sql = "insert into login values( ? , ? , ? , ? ) ";
                        PreparedStatement preparedStatement = connection.prepareStatement(sql);        
                        preparedStatement.setString(1,username);
                        preparedStatement.setString(2,password);
                        preparedStatement.setString(3,emailId);
                        preparedStatement.setString(4, urlData);
                        bool = preparedStatement.execute();
                        
                }
                catch(SQLException e){
                        e.printStackTrace();
                }
                finally{
                        connection.close();
                }
                return bool ; 
        }

        public void saveCategoryForUserName(String userName, String category) throws SQLException {
                // TODO Auto-generated method stub
                
                Boolean bool = false;
                Connection connection = DatabaseConnection.getConnection();
                try{
                        System.out.println(connection);
                        String sql = "insert into userNameCategoryBookIdBookName values( ? , ? , ? , ?) ";
                        PreparedStatement preparedStatement = connection.prepareStatement(sql);        
                        preparedStatement.setString(1,userName);
                        preparedStatement.setString(2,category);
                        preparedStatement.setString(3, "" );
                        preparedStatement.setString(4, "");
                        bool = preparedStatement.execute();
                }
                catch(SQLException e){
                        e.printStackTrace();
                }
                finally{
                        connection.close();
                }
                
        }

        public String getCategoryListForUser(String userName ) throws SQLException{
            String categoryList = "";
                   Connection connection = DatabaseConnection.getConnection();
                   try{
                           System.out.println(connection);
                           String sql = "select category  from userNameCategoryBookIdBookName  where username = ? ";
                           PreparedStatement preparedStatement = connection.prepareStatement(sql);        
                           preparedStatement.setString(1,userName);
                           ResultSet res = preparedStatement.executeQuery();
                           while(res.next()){
                                   categoryList = categoryList +","+ res.getString(1);
                           }
                   }
                   catch(SQLException e){
                           e.printStackTrace();
                   }
                   finally{
                           connection.close();
                   }
                   return categoryList ;
    }
        
        public void saveBookDetails(String username, String category, String bookName, String pageNumber,
                        String pageContent) throws SQLException {
                // TODO Auto-generated method stub
                Boolean bool = false;
                Connection connection = DatabaseConnection.getConnection();
                try{
                        // first of all , check whether the book already exists , if so update the details of
                        // page content and topic in the same book
                        /*String sqlToFetchBookList = "select bookname from bookdetails";
                        PreparedStatement preparedStatementForBookList = connection.prepareStatement(sqlToFetchBookList);
                        ResultSet resutlSet = preparedStatementForBookList.executeQuery();
                        String bookList = "";
                        while(resutlSet.next()){
                                bookList  = bookList + "," + resutlSet.getString(1);
                        }
                        if(bookList.contains(bookName)){
                                System.out.println("this is the updation case");
                                String sqlForUpdation = " update bookdetails set pagecontent = ? , topicnumberandname = ?  where bookname= ?  and username= ?  and category = ?  ";
                                PreparedStatement preparedStatementForUpdation = connection.prepareStatement(sqlForUpdation);
                                preparedStatementForUpdation.setString(1, pageContent);
                                preparedStatementForUpdation.setString(2, pageNumber);
                                preparedStatementForUpdation.setString(3, bookName);
                                preparedStatementForUpdation.setString(4, username);
                                preparedStatementForUpdation.setString(5, category);
                                Boolean boolForUpdation = preparedStatementForUpdation.execute();
                        }*/
                        
                        // insert new book details 
                        
                        // parsing to get the topic number from the page number
                        String[] strArrayOfTopicNumberAndTopicContent = pageNumber.split(":");
                        String topicNumber = strArrayOfTopicNumberAndTopicContent[0];
                        String bookId = bookName+":"+topicNumber;
                        
                        /**
                         *
                         * If you find bookId repeated on similar concept of above commented code , in that case just update the 
                         * page content . 
                         */
                        
                        String sqlToFetchBookIdList = "select bookId from bookDetails";
                        PreparedStatement preparedStatementForBookIdList = connection.prepareStatement(sqlToFetchBookIdList);
                        ResultSet resutlSet = preparedStatementForBookIdList.executeQuery();
                        String bookIdList = "";
                        while(resutlSet.next()){
                                bookIdList  = bookIdList + "," + resutlSet.getString(1);
                        }
                        
                        if(bookIdList.contains(bookId)){
                                System.out.println("this is the updation case");
                                String sqlForUpdation = " update bookDetails set pagecontent = ? , topicnumberandname = ?  where bookId= ?  and username= ?  and category = ?  ";
                                PreparedStatement preparedStatementForUpdation = connection.prepareStatement(sqlForUpdation);
                                preparedStatementForUpdation.setString(1, pageContent);
                                preparedStatementForUpdation.setString(2, pageNumber);
                                preparedStatementForUpdation.setString(3, bookId);
                                preparedStatementForUpdation.setString(4, username);
                                preparedStatementForUpdation.setString(5, category);
                                Boolean boolForUpdation = preparedStatementForUpdation.execute();
                        }
                        
                        
                        /**
                         * Write code for book id having book name appended with topic number ( after parsing first element of 
                         * page number ) . Insert book detail in bookId . 
                         */
                        
                        else{
                        System.out.println(connection);
                        System.out.println("this is the new book details insertion case ");
                        String sql = "insert into bookDetails values ( ? , ? , ? , ? , ? , ?) ";
                        PreparedStatement preparedStatement = connection.prepareStatement(sql);        
                        preparedStatement.setString(1,bookId);
                        preparedStatement.setString(2,bookName);
                        preparedStatement.setString(3, pageContent);
                        preparedStatement.setString(4, username);
                        preparedStatement.setString(5, category);
                        preparedStatement.setString(6, pageNumber);
                        System.out.println("Saving of the book details is done");
                        bool = preparedStatement.execute();
                        }
                        
                }
                catch(SQLException e){
                        e.printStackTrace();
                }
                finally{
                        connection.close();
                }
        }

		public String getCategoryList() throws SQLException {
			  String categoryList = "";
              Connection connection = DatabaseConnection.getConnection();
              try{
                      System.out.println(connection);
                      String sql = "SELECT distinct(category) FROM BOOKDETAILS  ";
                      PreparedStatement preparedStatement = connection.prepareStatement(sql);        
                      ResultSet res = preparedStatement.executeQuery();
                      while(res.next()){
                              categoryList = categoryList +","+ res.getString(1);
                      }
              }
              catch(SQLException e){
                      e.printStackTrace();
              }
              finally{
                      connection.close();
              }
              return categoryList ;
		}

		public Boolean ifUserNameExists(String userName) throws SQLException {
			 Boolean bool = false;
             Connection connection = DatabaseConnection.getConnection();
             try{
                     System.out.println(connection);
                     String sql = "SELECT distinct(username) FROM login  ";
                     PreparedStatement preparedStatement = connection.prepareStatement(sql);        
                     ResultSet res = preparedStatement.executeQuery();
                     while(res.next()){
                    	 if(userName.equalsIgnoreCase(res.getString(1))){{
                    		 bool = true;
                    	 }
                    	 }
                     }
             }
             catch(SQLException e){
                     e.printStackTrace();
             }
             finally{
                     connection.close();
             }
             return bool ;
		}

		public Boolean ifBookExists(String bookName , String category) throws SQLException {
			 Boolean bool = false;
             Connection connection = DatabaseConnection.getConnection();
             try{
                     System.out.println(connection);
                     String sql = "SELECT distinct(bookname), category FROM bookDetails  ";
                     PreparedStatement preparedStatement = connection.prepareStatement(sql);        
                     ResultSet res = preparedStatement.executeQuery();
                     while(res.next()){
                    	 if(bookName.equalsIgnoreCase(res.getString(1)) &&!(category.equalsIgnoreCase(res.getString(2)))){{
                    		 bool = true;
                    	 }
                    	 }
                     }
             }
             catch(SQLException e){
                     e.printStackTrace();
             }
             finally{
                     connection.close();
             }
             return bool ;
		}

		public Boolean saveBookPriceForBookName(String uniqueBookName,
				String bookPrice) throws SQLException {
			  Boolean bool = false;
              Connection connection = DatabaseConnection.getConnection();
              try{
                      System.out.println(connection);
                      String sql = "insert into bookPaymentDetails values( ? , ? , ? , ?) ";
                      PreparedStatement preparedStatement = connection.prepareStatement(sql);        
                      preparedStatement.setString(1,uniqueBookName);
                      preparedStatement.setString(2,bookPrice);
                      preparedStatement.setString(3, "" );
                      preparedStatement.setString(4, "");
                      bool = preparedStatement.execute();
              }
              catch(SQLException e){
                      e.printStackTrace();
              }
              finally{
                      connection.close();
              }
              return bool;
		}

		public String getPriceForUniqueBookName(String uniqueBookName)
				throws SQLException {
			  String price = "";
              Connection connection = DatabaseConnection.getConnection();
              try{
                      System.out.println(connection);
                      String sql = "select price from bookPaymentDetails where bookName = ? ";
                      PreparedStatement preparedStatement = connection.prepareStatement(sql);        
                      preparedStatement.setString(1,uniqueBookName);
                      ResultSet res = preparedStatement.executeQuery();
                      while(res.next()){
                    	  price = res.getString(1);
                      }
              }
              catch(SQLException e){
                      e.printStackTrace();
              }
              finally{
                      connection.close();
              }
              return price ;
		}

		public String moveFromInboxToDatabase(String purposeCode)
				throws SQLException {

			String host = "smtp.gmail.com";// change accordingly
			String mailStoreType = "pop3";
			String username = "thoughtsbookteam@gmail.com";// change accordingly
			String password = "ranigit1";// change accordingly

			String paymentStatus = check(host, mailStoreType, username, password , purposeCode);
			
			
			if(paymentStatus.equalsIgnoreCase("paid")){
				 Connection connection = DatabaseConnection.getConnection();
	              try{
	                      System.out.println(connection);
	                      String sql = "insert into usernamebooknameprice  values( ?) ";
	                      PreparedStatement preparedStatement = connection.prepareStatement(sql);        
	                      preparedStatement.setString(1,purposeCode);
	                      Boolean bool = preparedStatement.execute();
	              }
	              catch(SQLException e){
	                      e.printStackTrace();
	              }
	              finally{
	                      connection.close();
	              }
			}
			
			return paymentStatus;

		}
		
		public static String check(String host, String storeType, String user,
				String password , String purposeCode) 
		{
			String paymentStatus = "unpaid";
			try {
				

				//create properties field
				Properties properties = new Properties();

				properties.put("mail.pop3.host", host);
				properties.put("mail.pop3.port", "995");
				properties.put("mail.pop3.starttls.enable", "true");
				Session emailSession = Session.getDefaultInstance(properties);

				//create the POP3 store object and connect with the pop server
				Store store = emailSession.getStore("pop3s");

				store.connect(host, user, password);

				//create the folder object and open it
				Folder emailFolder = store.getFolder("INBOX");
				emailFolder.open(Folder.READ_ONLY);

				// retrieve the messages from the folder in an array and print it
				Message[] messages = emailFolder.getMessages();
				System.out.println("messages.length---" + messages.length);

				String filterText = purposeCode;


				for (int i = 0, n = messages.length; i < n; i++) {
					Message message = messages[i];
//					System.out.println("---------------------------------");
//					System.out.println("Email Number " + (i + 1));
//					System.out.println("Subject: " + message.getSubject());


					if (message.getSubject().contains(filterText)){
						paymentStatus = "paid";
					}
//					System.out.println("From: " + message.getFrom()[0]);
//					System.out.println("Text: " + message.getContent().toString());

				}
				System.out.println(paymentStatus);
				//close the store and folder objects
				emailFolder.close(false);
				store.close();

			} catch (NoSuchProviderException e) {
				e.printStackTrace();
			} catch (MessagingException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return paymentStatus;
		}

		public String getPaymentStatusForBook(String userNameAndUniqueBookName)
				throws SQLException {
			// TODO Auto-generated method stub
			// select * from usernamebooknameprice where usernamebooknameprice like 'doit-dodo-inr%'
			
				  String foundString = "";
	              Connection connection = DatabaseConnection.getConnection();
	              try{
	                      System.out.println(connection);
	                      String sql = "select * from usernamebooknameprice where usernamebooknameprice like 'doit-dodo-%' ";
	                      System.out.println(sql);
	                      PreparedStatement preparedStatement = connection.prepareStatement(sql);        
//	                      preparedStatement.setString(1,userNameAndUniqueBookName);
	                      ResultSet res = preparedStatement.executeQuery();
	                      while(res.next()){
	                    	  foundString = res.getString(1);
	                      }
	              }
	              catch(SQLException e){
	                      e.printStackTrace();
	              }
	              finally{
	                      connection.close();
	              }
	              return foundString ;
			
		}
		

}
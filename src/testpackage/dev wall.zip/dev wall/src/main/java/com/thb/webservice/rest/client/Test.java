package com.thb.webservice.rest.client;

import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import org.apache.commons.codec.binary.Base64;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.thb.db.DatabaseConnection;

public class Test {
 public static void main(String[] args) throws SQLException, UnsupportedEncodingException{
	 
	 
	 
	/*  byte[] valueDecoded= Base64.decodeBase64( "SGVsbG8gV29ybGQh".getBytes("UTF-8") );
      String passwordDecoded = new String(valueDecoded);*/
	 
	 List<String> listOfTrio = new ArrayList<String>();
	   listOfTrio.add("doit/sd/cda");
	   listOfTrio.add("doit/sd/cds");
	   listOfTrio.add("doit/sd/cdd");
	   listOfTrio.add("doit/sd/cdf");
	   listOfTrio.add("doit/sd/cdg");
	   
	   Integer lengthOfList = listOfTrio.size();
	   Integer randomIntegerOutOfLengthOfList = new Random().nextInt(lengthOfList);
	   
	   System.out.println(listOfTrio.get(randomIntegerOutOfLengthOfList));
       
	   String[] arrayOfTrio = listOfTrio.get(randomIntegerOutOfLengthOfList).split("/");
	   System.out.println(arrayOfTrio[0]);
	   System.out.println(arrayOfTrio[1]);
	   System.out.println(arrayOfTrio[2]);
	   
	   
	   
	/* Connection connection = DatabaseConnection.getConnection();
	 try{
	 System.out.println("hello");
 
	
	 System.out.println(connection);
	 
	 
	 String sql = "select password from login where username = ? ";
	 PreparedStatement preparedStatement = connection.prepareStatement(sql);	
	 preparedStatement.setString(1, "aparnesh");
	 ResultSet res = preparedStatement.executeQuery();
	 String str = "";
	 while(res.next()){
		 str = str + res.getString(1);
	 }
     System.out.println(str);	 
	 }
	 catch(SQLException e){
		 e.printStackTrace();
	 }
	 finally{
		 connection.close();
	 }*/
	 
	 
 }
}

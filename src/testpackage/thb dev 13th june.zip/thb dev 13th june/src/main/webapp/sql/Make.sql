create table test1 ( col1 varchar);
insert into test1 values('abcd');
alter table test1 add column col2 varchar;
insert into test1 values('abcde','lksjf')
update bookdetails set category='arts' where username='ma'
alter table login alter column urldata varchar(20000000)


create table login ( username varchar(255) , password varchar(255) , sex varchar (255) , urlData varchar (20000000))

create table userNameCategoryBookIdBookName ( username varchar(255) , category varchar(255) , bookid varchar(255) , bookname varchar(255))

create table bookDetails( bookid varchar(255) , bookname varchar(255) , pageContent varchar(2000000) , username varchar(255) , category varchar(255) , topicNumberAndName varchar(255))


alter table bookDetails alter column bookid varchar(255) not null; 
alter table bookDetails add primary key (bookid ) ( this is working and copied )


********************
payment gateway
					have price input with default value zero and one price update button adjacent to the enter topic name zone
					on update price button click , it should update the table bookPaymentDetails table
					while doing book search and subsequent read  : 
						let them have free read of topic one 
						once payment is initiated , and as a successful transaction , after the price is confirmed from email from gateway , only then the username-
						-is added to the paidThinkers list of the bookPaymentDetails table.
						if paid , add the thinker to the paidThinkers list in the table bookPaymentDetails
						on second topic , only actual text should be displayed if the thinker is in the paidThinkers list , else it displays text to 'pay to read'
						on second topic , if we find that the thinker is in the paidList of the table for the corresponding book , in that case let the content of-
						-the second topic be displayed .